<?php 
if (isset($_REQUEST['submit'])) {
	$conn = mysqli_connect("localhost","root","","test");
	if(!$conn){
		die("Database Error");
	}
	$fname = $_REQUEST['fname'];
	$lname = $_REQUEST['lname'];
	$mnum = $_REQUEST['mnum'];
	$city = $_REQUEST['city'];
	$pin = $_REQUEST['pin'];
	$occ = $_REQUEST['occ'];
	mysqli_query($conn,"INSERT INTO `temp`(`fname`, `lname`, `mnum`, `city`, `pin`, `occ`) VALUES ('".$fname."','".$lname."','".$mnum."','".$city."','".$pin."','".$occ."')");
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Assignment 5</title>
</head>
<body>
<form action="">
	<table>
		<thead>
			<tr><td colspan="2"><h1>Registration Form</h1></td></tr>
		</thead>
		<tr>
			<td><b>First name : </b></td>
			<td><input type="text" name="fname" required></td>
		</tr>
		<tr>
			<td><b>Last name : </b></td>
			<td><input type="text" name="lname" required></td>
		</tr>
		<tr>
			<td><b>Mobile no. : </b></td>
			<td><input type="text" name="mnum" onblur="valiDate(this);" required></td>
		</tr>
		<tr>
			<td><b>City : </b></td>
			<td><input type="text" name="city" required></td>
		</tr>
		<tr>
			<td><b>PINCODE : </b></td>
			<td><input type="text" name="pin" required></td>
		</tr>
		<tr>
			<td><b>Occupation : </b></td>
			<td>
			<label>Student </label><input type="radio" name="occ" value="stu">
			<label>Faculty </label><input type="radio" name="occ" value="fac">
			<label>Professional </label><input type="radio" name="occ" value="pro">
			<label>company / firm representatives </label><input type="radio" name="occ" value="com">
			</td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="submit" required></td>
		</tr>
	</table>
</form>
<script type="text/javascript">
	function valiDate(obj) {
		var patt = /[0-9]{10}/;
		var str = obj.value;
		if(!str.match(patt)){
			alert("Enter a valid mobile no.");
		}
	}
</script>
</body>
</html>